"use client"

import type React from "react"

import { useState, useMemo, useEffect } from "react"
import { Search, Menu, X, ChevronLeft, Download, Upload, BarChart3, Users, Lock, FileText, Plus } from "lucide-react"

type Employee = {
  id: string
  name: string
  employeeNo: string
}

type OperationLog = {
  id: string
  timestamp: string
  employeeNo: string
  employeeName: string
  operation: string
  bottleId?: string
  bottleBrand?: string
  details: string
}

type Customer = {
  id: string
  name: string
  kana: string
  totalVisits: number
  lastVisit: string
}

type Bottle = {
  id: string
  no: string
  neck: string
  type: "ウイスキー" | "焼酎" | "ブランデー" | "その他"
  brand: string
  person: string
  registeredDate: string
  customerId: string
  status: "保管中" | "飲みきり済"
  expiryDate: string
  location: string
  visitHistory?: string[] // Array of visit dates in "YYYY/MM/DD" format
}

const calculateExpiryDate = (startDate: Date, type: string): string => {
  const expiry = new Date(startDate)
  const months = type === "焼酎" ? 3 : 4
  expiry.setMonth(expiry.getMonth() + months)
  return expiry.toISOString().split("T")[0].replace(/-/g, "/")
}

const INITIAL_EMPLOYEES: Employee[] = [
  { id: "E-001", name: "佐藤 恵美", employeeNo: "101" },
  { id: "E-002", name: "田中 一郎", employeeNo: "102" },
  { id: "E-003", name: "鈴木 美咲", employeeNo: "103" },
  { id: "E-004", name: "高橋 健太", employeeNo: "104" },
  { id: "E-005", name: "山田 花子", employeeNo: "105" },
]

const INITIAL_CUSTOMERS: Customer[] = [
  { id: "C-8821", name: "田中 太郎", kana: "タナカ タロウ", totalVisits: 15, lastVisit: "2024/01/15" },
  { id: "C-9012", name: "鈴木 一郎", kana: "スズキ イチロウ", totalVisits: 8, lastVisit: "2024/01/10" },
  { id: "C-7734", name: "高橋 健二", kana: "タカハシ ケンジ", totalVisits: 24, lastVisit: "2024/01/20" },
  { id: "C-6543", name: "佐藤 花子", kana: "サトウ ハナコ", totalVisits: 12, lastVisit: "2024/01/18" },
  { id: "C-5432", name: "山田 次郎", kana: "ヤマダ ジロウ", totalVisits: 5, lastVisit: "2024/01/05" },
]

const INITIAL_BOTTLES: Bottle[] = [
  {
    id: "B-001",
    no: "001",
    neck: "102",
    type: "ウイスキー",
    brand: "山崎 12年",
    person: "佐藤",
    registeredDate: "2025/09/01",
    customerId: "C-8821",
    status: "保管中",
    expiryDate: "2026/01/01",
    location: "A-12",
    visitHistory: ["2025/12/20"],
  },
  {
    id: "B-002",
    no: "002",
    neck: "205",
    type: "焼酎",
    brand: "白州",
    person: "田中",
    registeredDate: "2025/10/15",
    customerId: "C-8821",
    status: "保管中",
    expiryDate: "2026/01/15",
    location: "B-05",
    visitHistory: ["2025/12/18"],
  },
  {
    id: "B-003",
    no: "003",
    neck: "088",
    type: "焼酎",
    brand: "黒霧島",
    person: "高橋",
    registeredDate: "2025/05/20",
    customerId: "C-8821",
    status: "飲みきり済",
    expiryDate: "2025/08/20",
    location: "C-22",
  },
  {
    id: "B-004",
    no: "004",
    neck: "311",
    type: "ウイスキー",
    brand: "響 17年",
    person: "鈴木",
    registeredDate: "2025/09/01",
    customerId: "C-9012",
    status: "保管中",
    expiryDate: "2026/01/01",
    location: "A-08",
    visitHistory: ["2025/12/15"],
  },
  {
    id: "B-005",
    no: "005",
    neck: "422",
    type: "焼酎",
    brand: "魔王",
    person: "山田",
    registeredDate: "2025/08/10",
    customerId: "C-9012",
    status: "飲みきり済",
    expiryDate: "2025/11/10",
    location: "D-15",
  },
  {
    id: "B-006",
    no: "006",
    neck: "533",
    type: "ブランデー",
    brand: "ヘネシーVSOP",
    person: "高橋",
    registeredDate: "2025/09/28",
    customerId: "C-7734",
    status: "保管中",
    expiryDate: "2026/01/28",
    location: "A-15",
    visitHistory: ["2025/12/10"],
  },
  {
    id: "B-007",
    no: "007",
    neck: "644",
    type: "ウイスキー",
    brand: "マッカラン 12年",
    person: "佐藤",
    registeredDate: "2025/10/05",
    customerId: "C-7734",
    status: "保管中",
    expiryDate: "2026/02/05",
    location: "B-10",
    visitHistory: ["2025/12/05"],
  },
  {
    id: "B-008",
    no: "008",
    neck: "755",
    type: "焼酎",
    brand: "森伊蔵",
    person: "田中",
    registeredDate: "2025/04/01",
    customerId: "C-7734",
    status: "飲みきり済",
    expiryDate: "2025/07/01",
    location: "C-18",
  },
  {
    id: "B-009",
    no: "009",
    neck: "866",
    type: "ウイスキー",
    brand: "知多",
    person: "鈴木",
    registeredDate: "2025/10/10",
    customerId: "C-6543",
    status: "保管中",
    expiryDate: "2026/02/10",
    location: "A-20",
    visitHistory: ["2025/12/18"],
  },
  {
    id: "B-010",
    no: "010",
    neck: "977",
    type: "焼酎",
    brand: "赤霧島",
    person: "山田",
    registeredDate: "2025/11/20",
    customerId: "C-6543",
    status: "保管中",
    expiryDate: "2026/02/20",
    location: "D-08",
    visitHistory: ["2025/12/12"],
  },
  {
    id: "B-011",
    no: "011",
    neck: "088",
    type: "ウイスキー",
    brand: "富士山麓",
    person: "高橋",
    registeredDate: "2025/12/15",
    customerId: "C-5432",
    status: "保管中",
    expiryDate: "2026/04/15",
    location: "B-22",
    visitHistory: ["2025/12/22"],
  },
  {
    id: "B-012",
    no: "012",
    neck: "199",
    type: "焼酎",
    brand: "伊佐美",
    person: "佐藤",
    registeredDate: "2025/12/05",
    customerId: "C-8821",
    status: "保管中",
    expiryDate: "2026/03/05",
    location: "C-05",
    visitHistory: ["2025/12/20"],
  },
  {
    id: "B-013",
    no: "013",
    neck: "200",
    type: "ウイスキー",
    brand: "グレンフィディック 12年",
    person: "田中",
    registeredDate: "2025/12/08",
    customerId: "C-9012",
    status: "保管中",
    expiryDate: "2026/04/08",
    location: "A-03",
    visitHistory: ["2025/12/15"],
  },
  {
    id: "B-014",
    no: "014",
    neck: "311",
    type: "焼酎",
    brand: "吉兆宝山",
    person: "鈴木",
    registeredDate: "2025/06/20",
    customerId: "C-7734",
    status: "飲みきり済",
    expiryDate: "2025/09/20",
    location: "D-12",
  },
  {
    id: "B-015",
    no: "015",
    neck: "422",
    type: "ブランデー",
    brand: "レミーマルタンVSOP",
    person: "山田",
    registeredDate: "2025/11/25",
    customerId: "C-6543",
    status: "保管中",
    expiryDate: "2026/03/25",
    location: "A-18",
    visitHistory: ["2025/12/12"],
  },
  {
    id: "B-016",
    no: "016",
    neck: "533",
    type: "ウイスキー",
    brand: "竹鶴",
    person: "高橋",
    registeredDate: "2025/12/01",
    customerId: "C-5432",
    status: "保管中",
    expiryDate: "2026/04/01",
    location: "B-15",
    visitHistory: ["2025/12/22"],
  },
  {
    id: "B-017",
    no: "017",
    neck: "644",
    type: "焼酎",
    brand: "村尾",
    person: "佐藤",
    registeredDate: "2025/04/15",
    customerId: "C-8821",
    status: "飲みきり済",
    expiryDate: "2025/07/15",
    location: "C-30",
  },
  {
    id: "B-018",
    no: "018",
    neck: "755",
    type: "ウイスキー",
    brand: "白州 18年",
    person: "田中",
    registeredDate: "2025/12/12",
    customerId: "C-9012",
    status: "保管中",
    expiryDate: "2026/04/12",
    location: "A-25",
    visitHistory: ["2025/12/15"],
  },
  {
    id: "B-019",
    no: "019",
    neck: "866",
    type: "焼酎",
    brand: "富乃宝山",
    person: "鈴木",
    registeredDate: "2025/12/20",
    customerId: "C-7734",
    status: "保管中",
    expiryDate: "2026/03/20",
    location: "D-20",
    visitHistory: ["2025/12/22"],
  },
  {
    id: "B-020",
    no: "020",
    neck: "977",
    type: "ウイスキー",
    brand: "イチローズモルト",
    person: "山田",
    registeredDate: "2025/11/28",
    customerId: "C-6543",
    status: "保管中",
    expiryDate: "2026/03/28",
    location: "B-08",
    visitHistory: ["2025/12/12"],
  },
]

const INITIAL_LOGS: OperationLog[] = [
  {
    id: "L-001",
    timestamp: "2024/01/20 14:30",
    employeeNo: "101",
    employeeName: "佐藤 恵美",
    operation: "来店記録",
    bottleId: "B-001",
    bottleBrand: "山崎 12年",
    details: "来店記録を登録し、期限を延長しました",
  },
  {
    id: "L-002",
    timestamp: "2024/01/18 18:45",
    employeeNo: "102",
    employeeName: "田中 一郎",
    operation: "新規登録",
    bottleId: "B-020",
    bottleBrand: "イチローズモルト",
    details: "新規ボトルを登録しました",
  },
  {
    id: "L-003",
    timestamp: "2024/01/15 16:20",
    employeeNo: "103",
    employeeName: "鈴木 美咲",
    operation: "追加",
    bottleId: "B-012",
    bottleBrand: "伊佐美",
    details: "既存顧客に新しいボトルを追加しました",
  },
]

const getExpiryStatus = (expiryDate: string, type: string) => {
  const today = new Date()
  today.setHours(0, 0, 0, 0)

  const expiry = new Date(expiryDate)
  expiry.setHours(0, 0, 0, 0)

  const diffTime = expiry.getTime() - today.getTime()
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))

  if (diffDays < 0) return { status: "expired", color: "text-red-600" }
  if (diffDays <= 14) return { status: "warning", color: "text-orange-600" }
  return { status: "normal", color: "" }
}

export default function BottleManager() {
  const [bottles, setBottles] = useState<Bottle[]>(INITIAL_BOTTLES)
  const [customers, setCustomers] = useState<Customer[]>(INITIAL_CUSTOMERS)
  const [employees, setEmployees] = useState<Employee[]>(INITIAL_EMPLOYEES)
  const [operationLogs, setOperationLogs] = useState<OperationLog[]>(INITIAL_LOGS)
  const [adminPassword, setAdminPassword] = useState("0000")
  const [editPassword, setEditPassword] = useState("0000")

  const [selectedBottleId, setSelectedBottleId] = useState<string | null>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [typeFilter, setTypeFilter] = useState("全て")
  const [showMenu, setShowMenu] = useState(false)
  const [currentView, setCurrentView] = useState<"bottles" | "history" | "settings" | "admin">("bottles")
  const [showNewRegistration, setShowNewRegistration] = useState(false)
  const [showAddBottle, setShowAddBottle] = useState(false)
  const [showVisitConfirm, setShowVisitConfirm] = useState(false)
  const [detailBottleId, setDetailBottleId] = useState<string | null>(null)
  const [showBackupNotice, setShowBackupNotice] = useState(false)
  const [isMounted, setIsMounted] = useState(false)

  const [employeeNoInput, setEmployeeNoInput] = useState("")
  const [passwordInput, setPasswordInput] = useState("")
  const [showEmployeeNoDialog, setShowEmployeeNoDialog] = useState(false)
  const [showPasswordDialog, setShowPasswordDialog] = useState(false)
  const [pendingAction, setPendingAction] = useState<"visit" | "add" | "new" | "edit" | "delete" | null>(null)

  const [adminTab, setAdminTab] = useState<"dashboard" | "employees" | "passwords" | "logs">("dashboard")
  const [showAddEmployee, setShowAddEmployee] = useState(false)
  const [newEmployeeName, setNewEmployeeName] = useState("")
  const [newEmployeeNo, setNewEmployeeNo] = useState("")

  const [newCustomerName, setNewCustomerName] = useState("")
  const [newCustomerKana, setNewCustomerKana] = useState("")
  const [newBottleNeck, setNewBottleNeck] = useState("")
  const [newBottleType, setNewBottleType] = useState<"ウイスキー" | "焼酎" | "ブランデー" | "その他">("ウイスキー")
  const [newBottleBrand, setNewBottleBrand] = useState("")
  const [newBottlePerson, setNewBottlePerson] = useState("")
  const [newBottleLocation, setNewBottleLocation] = useState("")
  const [newBottleDate, setNewBottleDate] = useState("")

  const showToast = (message: string) => {
    // Simple toast implementation using alert for now
    const toast = document.createElement("div")
    toast.textContent = message
    toast.style.cssText =
      "position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:#1f2937;color:white;padding:12px 24px;border-radius:8px;z-index:9999;"
    document.body.appendChild(toast)
    setTimeout(() => toast.remove(), 2000)
  }

  useEffect(() => {
    setIsMounted(true)
  }, [])

  useEffect(() => {
    if (!isMounted) return

    const savedBottles = localStorage.getItem("bottleDesk_bottles")
    const savedCustomers = localStorage.getItem("bottleDesk_customers")
    const savedEmployees = localStorage.getItem("bottleDesk_employees")
    const savedLogs = localStorage.getItem("bottleDesk_logs")
    const savedAdminPassword = localStorage.getItem("bottleDesk_adminPassword")
    const savedEditPassword = localStorage.getItem("bottleDesk_editPassword")

    if (savedBottles) {
      try {
        setBottles(JSON.parse(savedBottles))
      } catch (e) {
        console.error("Failed to load bottles from localStorage", e)
      }
    }

    if (savedCustomers) {
      try {
        setCustomers(JSON.parse(savedCustomers))
      } catch (e) {
        console.error("Failed to load customers from localStorage", e)
      }
    }

    if (savedEmployees) {
      try {
        setEmployees(JSON.parse(savedEmployees))
      } catch (e) {
        console.error("Failed to load employees from localStorage", e)
      }
    }

    if (savedLogs) {
      try {
        setOperationLogs(JSON.parse(savedLogs))
      } catch (e) {
        console.error("Failed to load logs from localStorage", e)
      }
    }

    if (savedAdminPassword) setAdminPassword(savedAdminPassword)
    if (savedEditPassword) setEditPassword(savedEditPassword)

    const lastBackupCheck = localStorage.getItem("bottleDesk_lastBackupCheck")
    const today = new Date()
    const todayStr = today.toISOString().split("T")[0]

    if (today.getDate() === 1 && lastBackupCheck !== todayStr) {
      setShowBackupNotice(true)
      localStorage.setItem("bottleDesk_lastBackupCheck", todayStr)
    }
  }, [isMounted])

  useEffect(() => {
    if (!isMounted) return
    localStorage.setItem("bottleDesk_bottles", JSON.stringify(bottles))
  }, [bottles, isMounted])

  useEffect(() => {
    if (!isMounted) return
    localStorage.setItem("bottleDesk_customers", JSON.stringify(customers))
  }, [customers, isMounted])

  useEffect(() => {
    if (!isMounted) return
    localStorage.setItem("bottleDesk_employees", JSON.stringify(employees))
  }, [employees, isMounted])

  useEffect(() => {
    if (!isMounted) return
    localStorage.setItem("bottleDesk_logs", JSON.stringify(operationLogs))
  }, [operationLogs, isMounted])

  useEffect(() => {
    if (!isMounted) return
    localStorage.setItem("bottleDesk_adminPassword", adminPassword)
  }, [adminPassword, isMounted])

  useEffect(() => {
    if (!isMounted) return
    localStorage.setItem("bottleDesk_editPassword", editPassword)
  }, [editPassword, isMounted])

  const validateEmployeeNo = (empNo: string): Employee | null => {
    return employees.find((e) => e.employeeNo === empNo) || null
  }

  const addLog = (operation: string, bottleId?: string, employeeNo?: string) => {
    const employee = employeeNo ? validateEmployeeNo(employeeNo) : null
    const bottle = bottleId ? bottles.find((b) => b.id === bottleId) : null

    const log: OperationLog = {
      id: `L-${Date.now()}`,
      timestamp: new Date().toLocaleString("ja-JP", {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
      }),
      employeeNo: employeeNo || "不明",
      employeeName: employee?.name || "不明",
      operation,
      bottleId,
      bottleBrand: bottle?.brand,
      details: `${operation}を実行しました`,
    }

    setOperationLogs((prev) => [log, ...prev])
  }

  const handleExportJSON = () => {
    const data = {
      bottles,
      customers,
      employees,
      operationLogs,
      adminPassword,
      editPassword,
      exportDate: new Date().toISOString(),
    }
    const json = JSON.stringify(data, null, 2)
    const blob = new Blob([json], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `bottle-desk-backup-${new Date().toISOString().split("T")[0]}.json`
    a.click()
    URL.revokeObjectURL(url)
  }

  const handleImportJSON = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const data = JSON.parse(e.target?.result as string)
        if (data.bottles && data.customers) {
          setBottles(data.bottles)
          setCustomers(data.customers)
          if (data.employees) setEmployees(data.employees)
          if (data.operationLogs) setOperationLogs(data.operationLogs)
          if (data.adminPassword) setAdminPassword(data.adminPassword)
          if (data.editPassword) setEditPassword(data.editPassword)
          alert("データを復元しました")
        } else {
          alert("不正なファイル形式です")
        }
      } catch (error) {
        alert("ファイルの読み込みに失敗しました")
      }
    }
    reader.readAsText(file)
  }

  const getLastVisitDate = (bottle: Bottle): string => {
    if (!bottle.visitHistory || bottle.visitHistory.length === 0) return "-"
    return bottle.visitHistory[bottle.visitHistory.length - 1]
  }

  const getDaysElapsed = (registeredDate: string): number => {
    const registered = new Date(registeredDate.replace(/\//g, "-"))
    const today = new Date()
    const diffTime = Math.abs(today.getTime() - registered.getTime())
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays
  }

  const hasMultipleBottles = (bottle: Bottle): boolean => {
    const sameBrand = bottles.filter(
      (b) => b.customerId === bottle.customerId && b.brand === bottle.brand && b.status === "保管中",
    )
    return sameBrand.length > 1
  }

  const handleVisitRecord = () => {
    if (!selectedBottle) return

    const employee = validateEmployeeNo(employeeNoInput)
    if (!employee) {
      alert("社員番号が登録されていません")
      return
    }

    const today = new Date()
    const newExpiryDate = calculateExpiryDate(today, selectedBottle.type)

    // Update visitHistory with current date
    setBottles((prev) =>
      prev.map((b) =>
        b.id === selectedBottle.id
          ? {
              ...b,
              expiryDate: newExpiryDate,
              visitHistory: [...(b.visitHistory || []), today.toISOString().split("T")[0].replace(/-/g, "/")],
            }
          : b,
      ),
    )

    const customer = customers.find((c) => c.id === selectedBottle.customerId)
    if (customer) {
      setCustomers((prev) =>
        prev.map((c) =>
          c.id === customer.id
            ? {
                ...c,
                totalVisits: c.totalVisits + 1,
                lastVisit: today.toISOString().split("T")[0].replace(/-/g, "/"),
              }
            : c,
        ),
      )
    }

    addLog("来店記録", selectedBottle.id, employeeNoInput)

    setShowVisitConfirm(false)
    setShowEmployeeNoDialog(false)
    setSelectedBottleId(null)
    setEmployeeNoInput("")
    setPendingAction(null)
    alert(`来店記録を更新しました\n新しい期限: ${newExpiryDate}`)
  }

  const handleEmployeeNoSubmit = () => {
    const employee = validateEmployeeNo(employeeNoInput)
    if (!employee) {
      alert("社員番号が登録されていません")
      return
    }

    if (pendingAction === "visit") {
      setShowEmployeeNoDialog(false)
      setShowVisitConfirm(true)
    } else if (pendingAction === "add") {
      setShowEmployeeNoDialog(false)
      setShowAddBottle(true)
    }
  }

  const handlePasswordSubmit = () => {
    if (passwordInput !== editPassword) {
      alert("パスワードが正しくありません")
      return
    }

    const employee = validateEmployeeNo(employeeNoInput)
    if (!employee) {
      alert("社員番号が登録されていません")
      return
    }

    if (pendingAction === "new") {
      setShowPasswordDialog(false)
      setShowNewRegistration(true)
    } else if (pendingAction === "edit") {
      alert("編集機能は近日実装予定です")
      setShowPasswordDialog(false)
      setPasswordInput("")
      setEmployeeNoInput("")
      setPendingAction(null)
    } else if (pendingAction === "delete") {
      alert("削除機能は近日実装予定です")
      setShowPasswordDialog(false)
      setPasswordInput("")
      setEmployeeNoInput("")
      setPendingAction(null)
    }
  }

  const handleNewRegistration = () => {
    if (
      !newCustomerName ||
      !newCustomerKana ||
      !newBottleNeck ||
      !newBottleBrand ||
      !newBottlePerson ||
      !newBottleLocation ||
      !newBottleDate
    ) {
      alert("すべての項目を入力してください")
      return
    }

    const newCustomerId = `C-${Date.now()}`
    const newBottleId = `B-${Date.now()}`
    const newBottleNo = String(bottles.length + 1).padStart(3, "0")

    const today = new Date(newBottleDate)
    const expiryDate = calculateExpiryDate(today, newBottleType)

    const customer: Customer = {
      id: newCustomerId,
      name: newCustomerName,
      kana: newCustomerKana,
      totalVisits: 1,
      lastVisit: newBottleDate.replace(/-/g, "/"),
    }

    const bottle: Bottle = {
      id: newBottleId,
      no: newBottleNo,
      neck: newBottleNeck,
      type: newBottleType,
      brand: newBottleBrand,
      person: newBottlePerson,
      registeredDate: newBottleDate.replace(/-/g, "/"),
      customerId: newCustomerId,
      status: "保管中",
      expiryDate,
      location: newBottleLocation,
      visitHistory: [newBottleDate.replace(/-/g, "/")], // Add initial visit history
    }

    setCustomers((prev) => [...prev, customer])
    setBottles((prev) => [...prev, bottle])
    addLog("新規登録", newBottleId, employeeNoInput)

    setShowNewRegistration(false)
    setNewCustomerName("")
    setNewCustomerKana("")
    setNewBottleNeck("")
    setNewBottleType("ウイスキー")
    setNewBottleBrand("")
    setNewBottlePerson("")
    setNewBottleLocation("")
    setNewBottleDate("")
    setPasswordInput("")
    setEmployeeNoInput("")
    setPendingAction(null)

    alert("新規顧客とボトルを登録しました")
  }

  const handleAddBottle = () => {
    if (
      !selectedBottle ||
      !newBottleNeck ||
      !newBottleBrand ||
      !newBottlePerson ||
      !newBottleLocation ||
      !newBottleDate
    ) {
      alert("すべての項目を入力してください")
      return
    }

    const newBottleId = `B-${Date.now()}`
    const newBottleNo = String(bottles.length + 1).padStart(3, "0")

    const today = new Date(newBottleDate)
    const expiryDate = calculateExpiryDate(today, newBottleType)

    const bottle: Bottle = {
      id: newBottleId,
      no: newBottleNo,
      neck: newBottleNeck,
      type: newBottleType,
      brand: newBottleBrand,
      person: newBottlePerson,
      registeredDate: newBottleDate.replace(/-/g, "/"),
      customerId: selectedBottle.customerId,
      status: "保管中",
      expiryDate,
      location: newBottleLocation,
      visitHistory: [newBottleDate.replace(/-/g, "/")], // Add initial visit history
    }

    setBottles((prev) => [...prev, bottle])
    addLog("追加", newBottleId, employeeNoInput)

    setShowAddBottle(false)
    setNewBottleNeck("")
    setNewBottleType("ウイスキー")
    setNewBottleBrand("")
    setNewBottlePerson("")
    setNewBottleLocation("")
    setNewBottleDate("")
    setEmployeeNoInput("")
    setPendingAction(null)
    setSelectedBottleId(null)

    alert("ボトルを追加しました")
  }

  const handleAdminAccess = () => {
    const password = prompt("管理者パスワードを入力してください:")
    if (password === adminPassword) {
      setCurrentView("admin")
      setShowMenu(false)
    } else if (password !== null) {
      alert("パスワードが正しくありません")
    }
  }

  const handleAddEmployee = () => {
    if (!newEmployeeName || !newEmployeeNo) {
      alert("社員名と社員Noを入力してください")
      return
    }

    const exists = employees.find((e) => e.employeeNo === newEmployeeNo)
    if (exists) {
      alert("この社員Noは既に登録されています")
      return
    }

    const newEmployee: Employee = {
      id: `E-${Date.now()}`,
      name: newEmployeeName,
      employeeNo: newEmployeeNo,
    }

    setEmployees((prev) => [...prev, newEmployee])
    setNewEmployeeName("")
    setNewEmployeeNo("")
    setShowAddEmployee(false)
    alert("社員を追加しました")
  }

  const displayBottles = bottles.filter((b) => b.status === "保管中")

  const filteredBottles = useMemo(() => {
    // The original code had 'displayBottles === "all" ? bottles : bottles.filter((b) => b.status === "保管中")' for the first argument. This has been simplified to directly filter for "保管中" status as intended by the context. The `displayBottles` variable is already filtered for "保管中" bottles.
    let bottleList = displayBottles

    if (typeFilter !== "全て") {
      // Changed 'all' to '全て' to match the enum values and UI text.
      bottleList = bottleList.filter((b) => b.type === typeFilter)
    }

    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase()
      bottleList = bottleList.filter((b) => {
        const customer = customers.find((c) => c.id === b.customerId)
        return (
          b.brand.toLowerCase().includes(term) ||
          b.neck.includes(term) ||
          b.no.includes(term) ||
          b.person.toLowerCase().includes(term) ||
          b.location?.toLowerCase().includes(term) ||
          (customer && (customer.name?.toLowerCase().includes(term) || customer.kana?.toLowerCase().includes(term)))
        )
      })
    }

    return bottleList
  }, [searchTerm, typeFilter, bottles, customers, displayBottles])

  const selectedBottle = selectedBottleId ? bottles.find((b) => b.id === selectedBottleId) : null
  const selectedCustomer = selectedBottle ? customers.find((c) => c.id === selectedBottle.customerId) : null

  const detailBottle = detailBottleId ? bottles.find((b) => b.id === detailBottleId) : selectedBottle
  const detailCustomer = detailBottle ? customers.find((c) => c.id === detailBottle.customerId) : null

  const customerBottles = detailCustomer
    ? bottles
        .filter((b) => b.customerId === detailCustomer.id)
        .sort((a, b) => {
          if (a.status === "保管中" && b.status === "飲みきり済") return -1
          if (a.status === "飲みきり済" && b.status === "保管中") return 1
          return 0
        })
    : []

  const totalBottles = bottles.filter((b) => b.status === "保管中").length
  const hitCount = filteredBottles.length
  const isSearching = searchTerm.trim() !== "" || typeFilter !== "全て" // Changed 'all' to '全て'

  const stats = useMemo(() => {
    const activeBottles = bottles.filter((b) => b.status === "保管中")
    const whiskyCount = activeBottles.filter((b) => b.type === "ウイスキー").length
    const shochuCount = activeBottles.filter((b) => b.type === "焼酎").length
    const brandyCount = activeBottles.filter((b) => b.type === "ブランデー").length
    const otherCount = activeBottles.filter((b) => b.type === "その他").length

    const personCounts: Record<string, number> = {}
    activeBottles.forEach((b) => {
      personCounts[b.person] = (personCounts[b.person] || 0) + 1
    })
    const topCasts = Object.entries(personCounts)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 5)

    return {
      total: activeBottles.length,
      whisky: whiskyCount,
      shochu: shochuCount,
      brandy: brandyCount,
      other: otherCount,
      topCasts,
    }
  }, [bottles])

  if (!isMounted) {
    return null
  }

  return (
    <div className="min-h-screen bg-white text-[#222] font-sans pb-20">
      {showBackupNotice && (
        <div className="fixed inset-0 z-[90] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50" onClick={() => setShowBackupNotice(false)} />
          <div className="relative bg-white rounded-lg shadow-xl p-6 max-w-sm w-full">
            <h3 className="font-bold text-lg mb-2">月次バックアップのお知らせ</h3>
            <p className="text-sm text-gray-600 mb-4">
              今日は月初めです。データのバックアップを推奨します。
              <br />
              設定画面からJSONファイルをダウンロードできます。
            </p>
            <button
              onClick={() => setShowBackupNotice(false)}
              className="w-full bg-blue-600 text-white py-2 rounded font-bold hover:bg-blue-700"
            >
              了解
            </button>
          </div>
        </div>
      )}

      <header className="fixed top-0 w-full h-12 bg-[#1A202C] text-white flex items-center justify-between px-4 z-50 shadow-md">
        <div className="w-6" />
        <span className="font-bold tracking-wider text-sm">BOTTLE DESK</span>
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              setPendingAction("new")
              setShowPasswordDialog(true)
            }}
            className="w-6 h-6 flex items-center justify-center hover:bg-white/10 rounded"
          >
            <Plus size={20} />
          </button>
          <button onClick={() => setShowMenu(!showMenu)} className="w-6 h-6 flex items-center justify-center">
            <Menu size={20} />
          </button>
        </div>
      </header>

      {showMenu && (
        <div className="fixed inset-0 z-[70] flex justify-end">
          <div className="absolute inset-0 bg-black/40" onClick={() => setShowMenu(false)} />
          <div className="relative w-72 bg-gradient-to-b from-gray-50 to-white h-full shadow-2xl">
            <div className="p-5 bg-[#1A202C]/95 text-white flex items-center justify-between border-b border-gray-700">
              <span className="font-bold text-lg tracking-wide">メニュー</span>
              <button onClick={() => setShowMenu(false)} className="hover:bg-white/10 p-1.5 rounded transition-colors">
                <X size={22} />
              </button>
            </div>

            {/* 上詰めメニュー */}
            <div className="pt-2">
              <button
                onClick={() => {
                  setCurrentView("bottles")
                  setShowMenu(false)
                }}
                className="w-full text-left px-6 py-4 hover:bg-blue-50 transition-colors text-base font-medium text-gray-700 hover:text-blue-600 border-b border-gray-100"
              >
                📋 一覧表
              </button>
              <button
                onClick={() => {
                  setPendingAction("new")
                  setShowPasswordDialog(true)
                  setShowMenu(false)
                }}
                className="w-full text-left px-6 py-4 hover:bg-blue-50 transition-colors text-base font-medium text-gray-700 hover:text-blue-600 border-b border-gray-100"
              >
                ➕ 新規登録
              </button>
              <button
                onClick={() => {
                  setCurrentView("bottles")
                  setShowMenu(false)
                }}
                className="w-full text-left px-6 py-4 hover:bg-blue-50 transition-colors text-base font-medium text-gray-700 hover:text-blue-600 border-b border-gray-100"
              >
                📖 取り扱い
              </button>
            </div>

            {/* 下詰めメニュー */}
            <div className="absolute bottom-0 w-full border-t-2 border-gray-200 bg-white">
              <button
                onClick={() => {
                  setCurrentView("settings")
                  setShowMenu(false)
                }}
                className="w-full text-left px-6 py-4 hover:bg-blue-50 transition-colors text-base font-medium text-gray-700 hover:text-blue-600 border-b border-gray-100"
              >
                💾 ダウンロード
              </button>
              <button
                onClick={() => {
                  handleAdminAccess()
                }}
                className="w-full text-left px-6 py-4 hover:bg-blue-50 transition-colors text-base font-medium text-gray-700 hover:text-blue-600"
              >
                🔑 管理者
              </button>
            </div>
          </div>
        </div>
      )}

      {currentView === "admin" && (
        <div className="pt-12">
          <div className="bg-gray-900 text-white p-4">
            <h2 className="text-xl font-bold">管理者ダッシュボード</h2>
          </div>
          <div className="flex border-b bg-white sticky top-12 z-10">
            <button
              onClick={() => setAdminTab("dashboard")}
              className={`flex-1 py-3 text-sm font-bold ${
                adminTab === "dashboard" ? "border-b-2 border-blue-600 text-blue-600" : "text-gray-600"
              }`}
            >
              <BarChart3 size={16} className="inline mr-1" />
              統計
            </button>
            <button
              onClick={() => setAdminTab("employees")}
              className={`flex-1 py-3 text-sm font-bold ${
                adminTab === "employees" ? "border-b-2 border-blue-600 text-blue-600" : "text-gray-600"
              }`}
            >
              <Users size={16} className="inline mr-1" />
              社員
            </button>
            <button
              onClick={() => setAdminTab("passwords")}
              className={`flex-1 py-3 text-sm font-bold ${
                adminTab === "passwords" ? "border-b-2 border-blue-600 text-blue-600" : "text-gray-600"
              }`}
            >
              <Lock size={16} className="inline mr-1" />
              PW
            </button>
            <button
              onClick={() => setAdminTab("logs")}
              className={`flex-1 py-3 text-sm font-bold ${
                adminTab === "logs" ? "border-b-2 border-blue-600 text-blue-600" : "text-gray-600"
              }`}
            >
              <FileText size={16} className="inline mr-1" />
              ログ
            </button>
          </div>

          {adminTab === "dashboard" && (
            <div className="p-6 space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                  <div className="text-xs text-gray-600 mb-1">保管中ボトル</div>
                  <div className="text-3xl font-bold text-blue-600">{stats.total}</div>
                  <div className="text-xs text-gray-500 mt-1">本</div>
                </div>
                <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                  <div className="text-xs text-gray-600 mb-1">登録顧客</div>
                  <div className="text-3xl font-bold text-green-600">{customers.length}</div>
                  <div className="text-xs text-gray-500 mt-1">名</div>
                </div>
              </div>

              <div className="border rounded-lg p-4">
                <h3 className="font-bold mb-3">酒類別内訳</h3>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">ウイスキー</span>
                    <span className="font-bold text-blue-600">{stats.whisky}本</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">焼酎</span>
                    <span className="font-bold text-orange-600">{stats.shochu}本</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">ブランデー</span>
                    <span className="font-bold text-amber-600">{stats.brandy}本</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">その他</span>
                    <span className="font-bold text-gray-600">{stats.other}本</span>
                  </div>
                </div>
              </div>

              <div className="border rounded-lg p-4">
                <h3 className="font-bold mb-3">キャスト別ボトル数ランキング</h3>
                <div className="space-y-2">
                  {stats.topCasts.map(([person, count], index) => (
                    <div key={person} className="flex justify-between items-center">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-gray-500 w-6">#{index + 1}</span>
                        <span className="text-sm">{person}</span>
                      </div>
                      <span className="font-bold text-blue-600">{count}本</span>
                    </div>
                  ))}
                </div>
              </div>

              <button
                onClick={() => setCurrentView("bottles")}
                className="w-full bg-gray-200 py-3 rounded font-bold hover:bg-gray-300"
              >
                ボトル管理に戻る
              </button>
            </div>
          )}

          {adminTab === "employees" && (
            <div className="p-6 space-y-4">
              <button
                onClick={() => setShowAddEmployee(true)}
                className="w-full bg-blue-600 text-white py-3 rounded font-bold hover:bg-blue-700"
              >
                ＋ 社員を追加
              </button>

              <div className="border rounded-lg divide-y">
                {employees.map((emp) => (
                  <div key={emp.id} className="p-4 flex justify-between items-center">
                    <div>
                      <div className="font-bold">{emp.name}</div>
                      <div className="text-xs text-gray-500">社員No: {emp.employeeNo}</div>
                    </div>
                  </div>
                ))}
              </div>

              <button
                onClick={() => setCurrentView("bottles")}
                className="w-full bg-gray-200 py-3 rounded font-bold hover:bg-gray-300"
              >
                ボトル管理に戻る
              </button>
            </div>
          )}

          {adminTab === "passwords" && (
            <div className="p-6 space-y-4">
              <div className="border rounded-lg p-4">
                <h3 className="font-bold mb-3">管理者パスワード</h3>
                <p className="text-xs text-gray-600 mb-2">管理者ページへのアクセスに使用</p>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={adminPassword}
                    onChange={(e) => setAdminPassword(e.target.value)}
                    className="flex-1 border rounded px-3 py-2"
                    placeholder="パスワード"
                  />
                </div>
              </div>

              <div className="border rounded-lg p-4">
                <h3 className="font-bold mb-3">編集・新規登録用パスワード</h3>
                <p className="text-xs text-gray-600 mb-2">ボトルの編集・新規登録・削除時に使用</p>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={editPassword}
                    onChange={(e) => setEditPassword(e.target.value)}
                    className="flex-1 border rounded px-3 py-2"
                    placeholder="パスワード"
                  />
                </div>
              </div>

              <button
                onClick={() => setCurrentView("bottles")}
                className="w-full bg-gray-200 py-3 rounded font-bold hover:bg-gray-300"
              >
                ボトル管理に戻る
              </button>
            </div>
          )}

          {adminTab === "logs" && (
            <div className="p-6 space-y-4">
              <div className="text-sm text-gray-600 mb-2">操作ログ ({operationLogs.length}件)</div>
              <div className="space-y-2">
                {operationLogs.map((log) => (
                  <div key={log.id} className="border rounded-lg p-3 text-sm">
                    <div className="flex justify-between items-start mb-2">
                      <span className="font-bold text-blue-600">{log.operation}</span>
                      <span className="text-xs text-gray-500">{log.timestamp}</span>
                    </div>
                    <div className="text-xs text-gray-600 space-y-1">
                      <div>
                        社員: {log.employeeName} (No. {log.employeeNo})
                      </div>
                      {log.bottleBrand && <div>ボトル: {log.bottleBrand}</div>}
                      <div>{log.details}</div>
                    </div>
                  </div>
                ))}
              </div>

              <button
                onClick={() => setCurrentView("bottles")}
                className="w-full bg-gray-200 py-3 rounded font-bold hover:bg-gray-300"
              >
                ボトル管理に戻る
              </button>
            </div>
          )}
        </div>
      )}

      {currentView === "settings" && (
        <div className="pt-12 p-6">
          <h2 className="text-xl font-bold mb-6">データ保存・復元</h2>
          <div className="space-y-4">
            <div className="border rounded-lg p-4">
              <h3 className="font-bold mb-2">データバックアップ</h3>
              <p className="text-sm text-gray-600 mb-3">データをJSONファイルとして保存・復元できます</p>
              <div className="flex gap-2">
                <button
                  onClick={handleExportJSON}
                  className="flex-1 bg-blue-600 text-white py-2 px-4 rounded font-bold hover:bg-blue-700 flex items-center justify-center gap-2"
                >
                  <Download size={16} />
                  <span>保存</span>
                </button>
                <label className="flex-1 bg-gray-600 text-white py-2 px-4 rounded font-bold hover:bg-gray-700 flex items-center justify-center gap-2 cursor-pointer">
                  <Upload size={16} />
                  <span>復元</span>
                  <input type="file" accept=".json" onChange={handleImportJSON} className="hidden" />
                </label>
              </div>
            </div>
            <button
              onClick={() => setCurrentView("bottles")}
              className="w-full bg-gray-200 py-3 rounded font-bold hover:bg-gray-300"
            >
              ボトル管理に戻る
            </button>
          </div>
        </div>
      )}

      {currentView === "history" && (
        <div className="pt-12 p-6">
          <h2 className="text-xl font-bold mb-4">履歴</h2>
          <p className="text-gray-500">履歴機能は近日実装予定です</p>
          <button
            onClick={() => setCurrentView("bottles")}
            className="mt-4 w-full bg-gray-200 py-3 rounded font-bold hover:bg-gray-300"
          >
            ボトル管理に戻る
          </button>
        </div>
      )}

      {currentView === "bottles" && (
        <main className="pt-12">
          <div className="p-3 space-y-2 bg-gray-50 border-b">
            <div className="flex gap-2">
              <select
                value={typeFilter}
                onChange={(e) => setTypeFilter(e.target.value)}
                className="border border-gray-300 rounded px-3 py-2 bg-white text-sm w-32"
              >
                <option>全て</option>
                <option>ウイスキー</option>
                <option>焼酎</option>
                <option>ブランデー</option>
                <option>その他</option>
              </select>
              <div className="relative flex-1">
                <Search className="absolute left-3 top-2.5 text-gray-400" size={18} />
                <input
                  type="text"
                  placeholder="銘柄・顧客名・カナ・キャスト・場所"
                  className="w-full border border-gray-300 rounded pl-10 pr-4 py-2 text-sm"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <div className="flex justify-end items-center gap-2 text-xs">
              {isSearching ? (
                <>
                  <span className="text-gray-500">ヒット数:</span>
                  <span className={`font-bold ${hitCount === 0 ? "text-red-600" : "text-blue-600"}`}>
                    {hitCount} / {totalBottles}
                  </span>
                </>
              ) : (
                <span className="font-bold text-gray-600">全 {totalBottles} 件</span>
              )}
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead className="bg-gradient-to-b from-gray-200 to-gray-150 text-gray-800 font-semibold sticky top-0 text-[10px] shadow-sm">
                <tr>
                  <th className="px-1 py-0.5 font-bold" style={{ width: "20px" }}>
                    ID
                  </th>
                  <th className="px-1 py-0.5 border-l border-gray-300"></th>
                  <th className="px-2 py-0.5 font-bold" style={{ width: "150px" }}>
                    顧客名
                  </th>
                  <th className="px-1 py-0.5 border-l border-gray-400"></th>
                  <th className="px-1 py-0.5 font-bold" style={{ width: "30px" }}>
                    ID
                  </th>
                  <th className="px-1 py-0.5 border-l border-gray-300"></th>
                  <th className="px-1 py-0.5 font-bold" style={{ width: "60px" }}>
                    ネック名
                  </th>
                  <th className="px-1 py-0.5 border-l border-gray-300"></th>
                  <th className="px-1 py-0.5 font-bold" style={{ width: "40px" }}>
                    指名
                  </th>
                  <th className="px-1 py-0.5 border-l border-gray-300"></th>
                  <th className="px-1 py-0.5 font-bold" style={{ width: "40px" }}>
                    種類
                  </th>
                  <th className="px-1 py-0.5 border-l border-gray-300"></th>
                  <th className="px-1 py-0.5 font-bold" style={{ width: "40px" }}>
                    銘柄
                  </th>
                  <th className="px-1 py-0.5 border-l border-gray-300"></th>
                  <th className="px-1 py-0.5 font-bold" style={{ width: "20px" }}>
                    卸日
                  </th>
                  <th className="px-1 py-0.5 border-l border-gray-400"></th>
                  <th className="px-1 py-0.5 font-bold" style={{ width: "20px" }}>
                    複数
                  </th>
                  <th className="px-1 py-0.5 border-l border-gray-300"></th>
                  <th className="px-1 py-0.5 font-bold" style={{ width: "20px" }}>
                    経過
                  </th>
                  <th className="px-1 py-0.5 border-l border-gray-300"></th>
                  <th className="px-1 py-0.5 font-bold" style={{ width: "20px" }}>
                    最終
                  </th>
                </tr>
              </thead>
              <tbody className="text-[10px]">
                {filteredBottles.map((bottle) => {
                  const customer = customers.find((c) => c.id === bottle.customerId)
                  const expiryInfo = getExpiryStatus(bottle.expiryDate, bottle.type)
                  const isSelected = selectedBottleId === bottle.id
                  const lastVisit = getLastVisitDate(bottle)
                  const daysElapsed = getDaysElapsed(bottle.registeredDate)
                  const isMultiple = hasMultipleBottles(bottle)

                  return (
                    <tr
                      key={bottle.id}
                      onClick={() => setSelectedBottleId(bottle.id)}
                      className={`border-b border-gray-100 cursor-pointer hover:bg-blue-50/50 transition-colors ${
                        isSelected ? "bg-blue-100/80 border-l-[6px] border-l-blue-600 shadow-sm" : ""
                      }`}
                      style={{ height: "28px" }}
                    >
                      <td className="px-1 py-0.5 text-gray-700 truncate" style={{ width: "20px" }}>
                        {customer?.id || "-"}
                      </td>
                      <td className="border-l border-gray-200"></td>
                      <td className="px-2 py-0.5 font-semibold text-gray-900 truncate" style={{ width: "150px" }}>
                        {customer?.name || "-"}
                      </td>
                      <td className="border-l border-gray-300"></td>
                      <td className="px-1 py-0.5 text-gray-700 truncate" style={{ width: "30px" }}>
                        {bottle.no}
                      </td>
                      <td className="border-l border-gray-200"></td>
                      <td className="px-1 py-0.5 text-gray-700 truncate" style={{ width: "60px" }}>
                        {bottle.neck}
                      </td>
                      <td className="border-l border-gray-200"></td>
                      <td className="px-1 py-0.5 text-gray-700 truncate" style={{ width: "40px" }}>
                        {bottle.person}
                      </td>
                      <td className="border-l border-gray-200"></td>
                      <td className="px-1 py-0.5 text-gray-700 truncate" style={{ width: "40px" }}>
                        {bottle.type}
                      </td>
                      <td className="border-l border-gray-200"></td>
                      <td className="px-1 py-0.5 text-gray-700 truncate" style={{ width: "40px" }}>
                        {bottle.brand}
                      </td>
                      <td className="border-l border-gray-200"></td>
                      <td className="px-1 py-0.5 text-gray-700 truncate" style={{ width: "20px" }}>
                        {bottle.registeredDate.split("-").slice(1).join("/")}
                      </td>
                      <td className="border-l border-gray-300"></td>
                      <td className="px-1 py-0.5 text-center text-gray-700" style={{ width: "20px" }}>
                        {isMultiple ? "●" : ""}
                      </td>
                      <td className="border-l border-gray-200"></td>
                      <td className="px-1 py-0.5 text-center text-gray-700" style={{ width: "20px" }}>
                        {daysElapsed}d
                      </td>
                      <td className="border-l border-gray-200"></td>
                      <td className="px-1 py-0.5 text-gray-700 truncate" style={{ width: "20px" }}>
                        {lastVisit ? lastVisit.split("-").slice(1).join("/") : "-"}
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>

          {hitCount === 0 && (
            <div className="p-8 text-center text-gray-400">
              <Search size={48} className="mx-auto mb-2 opacity-30" />
              <p>該当するボトルが見つかりませんでした</p>
            </div>
          )}
        </main>
      )}

      {/* Detail modal - updated with location display */}
      {detailBottleId && detailBottle && detailCustomer && (
        <div className="fixed inset-0 z-[60] md:flex md:justify-end">
          <div className="absolute inset-0 bg-black/40" onClick={() => setDetailBottleId(null)} />
          <div className="relative w-full md:w-[90%] md:max-w-md bg-white h-full shadow-2xl overflow-y-auto">
            <div className="sticky top-0 bg-white border-b p-4 flex items-center gap-3 z-10">
              <button onClick={() => setDetailBottleId(null)} className="text-blue-600 flex items-center gap-1">
                <ChevronLeft size={20} /> <span className="text-sm">戻る</span>
              </button>
            </div>

            <div className="p-6 border-b bg-gray-50">
              <h2 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">Customer</h2>
              <div className="text-2xl font-bold mb-1">{detailCustomer.name} 様</div>
              <div className="text-sm text-gray-500 mb-4">{detailCustomer.kana}</div>

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <div className="text-xs text-gray-500">顧客ID</div>
                  <div className="font-mono font-bold text-sm">{detailCustomer.id}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-500">累計来店回数</div>
                  <div className="font-bold text-sm">{detailCustomer.totalVisits}回</div>
                </div>
              </div>

              <div>
                <div className="text-xs text-gray-500 mb-1">直近来店日</div>
                <div className="bg-white p-2 rounded text-sm font-bold border">{detailCustomer.lastVisit}</div>
              </div>
            </div>

            <div className="p-6 border-b">
              <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-3">
                所有ボトル一覧 ({customerBottles.length}本)
              </h3>
              <div className="space-y-2">
                {customerBottles.map((bottle) => {
                  const expiryInfo = getExpiryStatus(bottle.expiryDate, bottle.type)
                  const isActive = detailBottle?.id === bottle.id
                  return (
                    <button
                      key={bottle.id}
                      onClick={() => setDetailBottleId(bottle.id)}
                      className={`w-full text-left p-3 rounded border transition-colors ${
                        isActive ? "bg-blue-50" : "bg-white border-gray-200 hover:bg-gray-50"
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <div className="font-bold text-sm truncate">{bottle.brand}</div>
                          <div className="text-xs text-gray-500 mt-0.5">
                            {bottle.location} / {bottle.type}
                          </div>
                        </div>
                        <div className="flex flex-col items-end gap-1">
                          <span
                            className={`text-[10px] px-2 py-0.5 rounded font-medium whitespace-nowrap ${
                              bottle.status === "保管中" ? "bg-blue-100 text-blue-700" : "bg-gray-100 text-gray-500"
                            }`}
                          >
                            {bottle.status}
                          </span>
                          {bottle.status === "保管中" && (
                            <span className={`text-[10px] font-bold ${expiryInfo.color}`}>{bottle.expiryDate}</span>
                          )}
                        </div>
                      </div>
                    </button>
                  )
                })}
              </div>
            </div>

            {detailBottle && (
              <div className="p-6">
                <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-3">ボトル詳細</h3>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="text-xs text-gray-500">No</div>
                      <div className="font-bold">{detailBottle.no}</div>
                    </div>
                    <div>
                      <div className="text-xs text-gray-500">ネック番号</div>
                      <div className="font-mono font-bold">{detailBottle.neck}</div>
                    </div>
                  </div>

                  <div>
                    <div className="text-xs text-gray-500 mb-1">銘柄</div>
                    <div className="bg-gray-50 p-3 rounded font-bold border">{detailBottle.brand}</div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="text-xs text-gray-500">種類</div>
                      <div className="font-bold">{detailBottle.type}</div>
                    </div>
                    <div>
                      <div className="text-xs text-gray-500">指名担当</div>
                      <div className="font-bold">{detailBottle.person}</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="text-xs text-gray-500">保管場所</div>
                      <div className="font-bold">{detailBottle.location}</div>
                    </div>
                    <div>
                      <div className="text-xs text-gray-500">卸日</div>
                      <div className="font-bold text-sm">{detailBottle.registeredDate}</div>
                    </div>
                  </div>

                  <div>
                    <div className="text-xs text-gray-500 mb-1">期限</div>
                    <div className="font-bold text-sm">{detailBottle.expiryDate}</div>
                  </div>

                  <div>
                    <div className="text-xs text-gray-500 mb-1">ステータス</div>
                    <div
                      className={`inline-block px-3 py-1 rounded text-sm font-bold ${
                        detailBottle.status === "保管中" ? "bg-blue-100 text-blue-700" : "bg-gray-100 text-gray-600"
                      }`}
                    >
                      {detailBottle.status}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {showNewRegistration && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center p-4 overflow-y-auto">
          <div
            className="absolute inset-0 bg-black/50"
            onClick={() => {
              setShowNewRegistration(false)
              setPasswordInput("")
              setEmployeeNoInput("")
              setPendingAction(null)
            }}
          />
          <div className="relative bg-white rounded-lg shadow-xl p-6 max-w-md w-full my-8">
            <h3 className="font-bold text-lg mb-4">新規顧客・ボトル登録</h3>

            <div className="space-y-3">
              <div>
                <label className="text-xs text-gray-600 block mb-1">顧客名</label>
                <input
                  type="text"
                  value={newCustomerName}
                  onChange={(e) => setNewCustomerName(e.target.value)}
                  className="w-full border rounded px-3 py-2"
                  placeholder="例: 田中 太郎"
                />
              </div>

              <div>
                <label className="text-xs text-gray-600 block mb-1">カナ</label>
                <input
                  type="text"
                  value={newCustomerKana}
                  onChange={(e) => setNewCustomerKana(e.target.value)}
                  className="w-full border rounded px-3 py-2"
                  placeholder="例: タナカ タロウ"
                />
              </div>

              <div className="border-t pt-3">
                <h4 className="font-bold text-sm mb-3">ボトル情報</h4>

                <div className="space-y-3">
                  <div>
                    <label className="text-xs text-gray-600 block mb-1">ネック番号</label>
                    <input
                      type="text"
                      value={newBottleNeck}
                      onChange={(e) => setNewBottleNeck(e.target.value)}
                      className="w-full border rounded px-3 py-2"
                      placeholder="例: 102"
                    />
                  </div>

                  <div>
                    <label className="text-xs text-gray-600 block mb-1">種類</label>
                    <select
                      value={newBottleType}
                      onChange={(e) => setNewBottleType(e.target.value as any)}
                      className="w-full border rounded px-3 py-2"
                    >
                      <option>ウイスキー</option>
                      <option>焼酎</option>
                      <option>ブランデー</option>
                      <option>その他</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs text-gray-600 block mb-1">銘柄</label>
                    <input
                      type="text"
                      value={newBottleBrand}
                      onChange={(e) => setNewBottleBrand(e.target.value)}
                      className="w-full border rounded px-3 py-2"
                      placeholder="例: 山崎 12年"
                    />
                  </div>

                  <div>
                    <label className="text-xs text-gray-600 block mb-1">指名担当</label>
                    <input
                      type="text"
                      value={newBottlePerson}
                      onChange={(e) => setNewBottlePerson(e.target.value)}
                      className="w-full border rounded px-3 py-2"
                      placeholder="例: 佐藤"
                    />
                  </div>

                  <div>
                    <label className="text-xs text-gray-600 block mb-1">保管場所</label>
                    <input
                      type="text"
                      value={newBottleLocation}
                      onChange={(e) => setNewBottleLocation(e.target.value)}
                      className="w-full border rounded px-3 py-2"
                      placeholder="例: A-12"
                    />
                  </div>

                  <div>
                    <label className="text-xs text-gray-600 block mb-1">卸日</label>
                    <input
                      type="date"
                      value={newBottleDate}
                      onChange={(e) => setNewBottleDate(e.target.value)}
                      className="w-full border rounded px-3 py-2"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="flex gap-2 mt-6">
              <button
                onClick={() => {
                  setShowNewRegistration(false)
                  setPasswordInput("")
                  setEmployeeNoInput("")
                  setPendingAction(null)
                }}
                className="flex-1 bg-gray-200 text-gray-700 py-2 rounded font-bold hover:bg-gray-300"
              >
                キャンセル
              </button>
              <button
                onClick={handleNewRegistration}
                className="flex-1 bg-blue-600 text-white py-2 rounded font-bold hover:bg-blue-700"
              >
                登録
              </button>
            </div>
          </div>
        </div>
      )}

      {showAddBottle && selectedBottle && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center p-4 overflow-y-auto">
          <div
            className="absolute inset-0 bg-black/50"
            onClick={() => {
              setShowAddBottle(false)
              setEmployeeNoInput("")
              setPendingAction(null)
            }}
          />
          <div className="relative bg-white rounded-lg shadow-xl p-6 max-w-md w-full my-8">
            <h3 className="font-bold text-lg mb-2">ボトル追加</h3>
            <p className="text-sm text-gray-600 mb-4">{selectedCustomer?.name} 様にボトルを追加します</p>

            <div className="space-y-3">
              <div>
                <label className="text-xs text-gray-600 block mb-1">ネック番号</label>
                <input
                  type="text"
                  value={newBottleNeck}
                  onChange={(e) => setNewBottleNeck(e.target.value)}
                  className="w-full border rounded px-3 py-2"
                  placeholder="例: 102"
                />
              </div>

              <div>
                <label className="text-xs text-gray-600 block mb-1">種類</label>
                <select
                  value={newBottleType}
                  onChange={(e) => setNewBottleType(e.target.value as any)}
                  className="w-full border rounded px-3 py-2"
                >
                  <option>ウイスキー</option>
                  <option>焼酎</option>
                  <option>ブランデー</option>
                  <option>その他</option>
                </select>
              </div>

              <div>
                <label className="text-xs text-gray-600 block mb-1">銘柄</label>
                <input
                  type="text"
                  value={newBottleBrand}
                  onChange={(e) => setNewBottleBrand(e.target.value)}
                  className="w-full border rounded px-3 py-2"
                  placeholder="例: 山崎 12年"
                />
              </div>

              <div>
                <label className="text-xs text-gray-600 block mb-1">指名担当</label>
                <input
                  type="text"
                  value={newBottlePerson}
                  onChange={(e) => setNewBottlePerson(e.target.value)}
                  className="w-full border rounded px-3 py-2"
                  placeholder="例: 佐藤"
                />
              </div>

              <div>
                <label className="text-xs text-gray-600 block mb-1">保管場所</label>
                <input
                  type="text"
                  value={newBottleLocation}
                  onChange={(e) => setNewBottleLocation(e.target.value)}
                  className="w-full border rounded px-3 py-2"
                  placeholder="例: A-12"
                />
              </div>

              <div>
                <label className="text-xs text-gray-600 block mb-1">卸日</label>
                <input
                  type="date"
                  value={newBottleDate}
                  onChange={(e) => setNewBottleDate(e.target.value)}
                  className="w-full border rounded px-3 py-2"
                />
              </div>
            </div>

            <div className="flex gap-2 mt-6">
              <button
                onClick={() => {
                  setShowAddBottle(false)
                  setEmployeeNoInput("")
                  setPendingAction(null)
                }}
                className="flex-1 bg-gray-200 text-gray-700 py-2 rounded font-bold hover:bg-gray-300"
              >
                キャンセル
              </button>
              <button
                onClick={handleAddBottle}
                className="flex-1 bg-blue-600 text-white py-2 rounded font-bold hover:bg-blue-700"
              >
                追加
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Dialogs remain mostly unchanged */}
      {showEmployeeNoDialog && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-black/50"
            onClick={() => {
              setShowEmployeeNoDialog(false)
              setEmployeeNoInput("")
              setPendingAction(null)
            }}
          />
          <div className="relative bg-white rounded-lg shadow-xl p-6 max-w-sm w-full">
            <h3 className="font-bold text-lg mb-2">社員番号の入力</h3>
            <p className="text-sm text-gray-600 mb-4">社員番号を入力してください</p>
            <input
              type="text"
              value={employeeNoInput}
              onChange={(e) => setEmployeeNoInput(e.target.value)}
              className="w-full border rounded px-3 py-2 mb-4"
              placeholder="例: 101"
              autoFocus
            />
            <div className="flex gap-2">
              <button
                onClick={() => {
                  setShowEmployeeNoDialog(false)
                  setEmployeeNoInput("")
                  setPendingAction(null)
                }}
                className="flex-1 bg-gray-200 text-gray-700 py-2 rounded font-bold hover:bg-gray-300"
              >
                キャンセル
              </button>
              <button
                onClick={handleEmployeeNoSubmit}
                className="flex-1 bg-blue-600 text-white py-2 rounded font-bold hover:bg-blue-700"
              >
                確認
              </button>
            </div>
          </div>
        </div>
      )}

      {showPasswordDialog && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-black/50"
            onClick={() => {
              setShowPasswordDialog(false)
              setPasswordInput("")
              setEmployeeNoInput("")
              setPendingAction(null)
            }}
          />
          <div className="relative bg-white rounded-lg shadow-xl p-6 max-w-sm w-full">
            <h3 className="font-bold text-lg mb-2">パスワードと社員番号の入力</h3>
            <p className="text-sm text-gray-600 mb-4">編集用パスワードと社員番号を入力してください</p>
            <input
              type="password"
              value={passwordInput}
              onChange={(e) => setPasswordInput(e.target.value)}
              className="w-full border rounded px-3 py-2 mb-3"
              placeholder="パスワード"
              autoFocus
            />
            <input
              type="text"
              value={employeeNoInput}
              onChange={(e) => setEmployeeNoInput(e.target.value)}
              className="w-full border rounded px-3 py-2 mb-4"
              placeholder="社員番号 (例: 101)"
            />
            <div className="flex gap-2">
              <button
                onClick={() => {
                  setShowPasswordDialog(false)
                  setPasswordInput("")
                  setEmployeeNoInput("")
                  setPendingAction(null)
                }}
                className="flex-1 bg-gray-200 text-gray-700 py-2 rounded font-bold hover:bg-gray-300"
              >
                キャンセル
              </button>
              <button
                onClick={handlePasswordSubmit}
                className="flex-1 bg-blue-600 text-white py-2 rounded font-bold hover:bg-blue-700"
              >
                確認
              </button>
            </div>
          </div>
        </div>
      )}

      {showVisitConfirm && selectedCustomer && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50" onClick={() => setShowVisitConfirm(false)} />
          <div className="relative bg-white rounded-lg shadow-xl p-6 max-w-sm w-full">
            <h3 className="font-bold text-lg mb-2">来店記録</h3>
            <p className="text-sm text-gray-600 mb-4">
              {selectedCustomer.name} 様の来店を記録しますか？
              <br />
              <span className="text-xs text-gray-500">
                ※ 期限が自動延長されます（{selectedBottle?.type === "焼酎" ? "3ヶ月" : "4ヶ月"}）
              </span>
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => setShowVisitConfirm(false)}
                className="flex-1 bg-gray-200 text-gray-700 py-2 rounded font-bold hover:bg-gray-300"
              >
                キャンセル
              </button>
              <button
                onClick={handleVisitRecord}
                className="flex-1 bg-blue-600 text-white py-2 rounded font-bold hover:bg-blue-700"
              >
                記録する
              </button>
            </div>
          </div>
        </div>
      )}

      {showAddEmployee && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50" onClick={() => setShowAddEmployee(false)} />
          <div className="relative bg-white rounded-lg shadow-xl p-6 max-w-sm w-full">
            <h3 className="font-bold text-lg mb-2">社員を追加</h3>
            <p className="text-sm text-gray-600 mb-4">社員名と社員番号を入力してください</p>
            <input
              type="text"
              value={newEmployeeName}
              onChange={(e) => setNewEmployeeName(e.target.value)}
              className="w-full border rounded px-3 py-2 mb-3"
              placeholder="社員名 (例: 山田 太郎)"
              autoFocus
            />
            <input
              type="text"
              value={newEmployeeNo}
              onChange={(e) => setNewEmployeeNo(e.target.value)}
              className="w-full border rounded px-3 py-2 mb-4"
              placeholder="社員No (例: 106)"
            />
            <div className="flex gap-2">
              <button
                onClick={() => {
                  setShowAddEmployee(false)
                  setNewEmployeeName("")
                  setNewEmployeeNo("")
                }}
                className="flex-1 bg-gray-200 text-gray-700 py-2 rounded font-bold hover:bg-gray-300"
              >
                キャンセル
              </button>
              <button
                onClick={handleAddEmployee}
                className="flex-1 bg-blue-600 text-white py-2 rounded font-bold hover:bg-blue-700"
              >
                追加
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="fixed bottom-0 w-full bg-white border-t shadow-lg z-40">
        {/* Selection indicator - blue line shown only when a row is selected */}
        {selectedBottleId && <div className="w-full h-[2px] bg-[#2563EB]" />}

        {/* Guide message - shown only when no row is selected */}
        {!selectedBottleId && (
          <div className="w-full py-2 text-center text-sm text-gray-500 border-b">レコードを選択してください</div>
        )}

        <div className="grid grid-cols-3 gap-0 divide-x">
          <button
            disabled={!selectedBottleId}
            onClick={() => {
              if (!selectedBottleId) {
                showToast("レコードを選択してください")
              } else {
                setDetailBottleId(selectedBottleId)
              }
            }}
            className={`py-4 font-bold text-sm hover:bg-gray-50 transition-colors ${
              !selectedBottleId ? "opacity-35" : ""
            }`}
          >
            参照
          </button>
          <button
            disabled={!selectedBottleId}
            onClick={() => {
              if (!selectedBottleId) {
                showToast("レコードを選択してください")
              } else {
                setPendingAction("add")
                setShowEmployeeNoDialog(true)
              }
            }}
            className={`py-4 font-bold text-sm hover:bg-gray-50 transition-colors ${
              !selectedBottleId ? "opacity-35" : ""
            }`}
          >
            追加
          </button>
          <button
            disabled={!selectedBottleId}
            onClick={() => {
              if (!selectedBottleId) {
                showToast("レコードを選択してください")
              } else {
                setPendingAction("visit")
                setShowEmployeeNoDialog(true)
              }
            }}
            className={`py-4 font-bold text-sm text-blue-600 hover:bg-blue-50 transition-colors ${
              !selectedBottleId ? "opacity-35" : ""
            }`}
          >
            来店
          </button>
        </div>
      </div>
    </div>
  )
}

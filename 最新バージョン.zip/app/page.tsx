import { Suspense } from "react"
import BottleManager from "@/components/bottle-manager"

export default function BottleManagementApp() {
  return (
    <Suspense fallback={null}>
      <BottleManager />
    </Suspense>
  )
}
